/**
  ******************************************************************************
  * File Name          : gpio.c
  * Description        : This file provides code for the configuration
  *                      of all used GPIO pins.
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

#include "gpio.h"

void MX_GPIO_Init(void) {
    GPIO_InitTypeDef cfg = {0};
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOH_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();

    // Set output latches before selecting output mode.
    HAL_GPIO_WritePin(GPIOC, M0_nCS_Pin | CH394Q_CS_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(GPIOA, CH394Q_RESET_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, EN_GATE_Pin | AUX_L_Pin | AUX_H_Pin, GPIO_PIN_RESET);
    cfg.Mode = GPIO_MODE_OUTPUT_PP;
    cfg.Pull = GPIO_NOPULL;
    cfg.Speed = GPIO_SPEED_FREQ_LOW;
    cfg.Pin = M0_nCS_Pin | CH394Q_CS_Pin;
    HAL_GPIO_Init(GPIOC, &cfg);
    cfg.Pin = CH394Q_RESET_Pin;
    HAL_GPIO_Init(GPIOA, &cfg);
    cfg.Pin = EN_GATE_Pin | AUX_L_Pin | AUX_H_Pin;
    HAL_GPIO_Init(GPIOB, &cfg);

    // Disabled extension modules own no alternate functions or EXTI lines.
    cfg.Mode = GPIO_MODE_INPUT;
    cfg.Pin = M0_ENC_Z_Pin | HX711_DOUT_Pin | HX711_SCK_Pin | CH394Q_INT_Pin;
    HAL_GPIO_Init(GPIOC, &cfg);
    cfg.Pin = HX711_RATE_Pin;
    HAL_GPIO_Init(GPIOB, &cfg);
    cfg.Pull = GPIO_PULLUP;
    cfg.Pin = STOP_Pin;
    HAL_GPIO_Init(GPIOA, &cfg);
    cfg.Pin = nFAULT_Pin;
    HAL_GPIO_Init(GPIOD, &cfg);
}
